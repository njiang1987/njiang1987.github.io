//
//  BitWatchKit.h
//  BitWatchKit
//
//  Created by Mic Pringle on 19/11/2014.
//  Copyright (c) 2014 Razeware LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BitWatchKit.
FOUNDATION_EXPORT double BitWatchKitVersionNumber;

//! Project version string for BitWatchKit.
FOUNDATION_EXPORT const unsigned char BitWatchKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BitWatchKit/PublicHeader.h>


